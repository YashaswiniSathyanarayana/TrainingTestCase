import java.sql.*;
import java.util.Scanner;

public class Login {
	static final String LOGIN_QUERY = "SELECT * FROM USER_REGISTRATION WHERE EMAIL_ID =? AND PASSWORD =?;";
	public static void login() {
		Scanner sc = new Scanner(System.in);
		try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
				PreparedStatement ps = con.prepareStatement(LOGIN_QUERY);){
			System.out.println("Please enter the log in credentials");
			System.out.println("*************************************************");
			System.out.println("Enter the registered EMAIL_ID");
			String email_id = sc.nextLine();
			System.out.println("Enter the password");
			String password = sc.nextLine();
			
			ps.setString(1, email_id);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			boolean check = true;
			if(rs.next()) {
				Logout.updateStatusToLogout(email_id,"Active");
				while(check) {
					System.out.println("=================================================================================");
					System.out.println("Hi "+ rs.getString("NAME"));
					System.out.println("***********************ENTER THE ACTION YOU WANT TO PERFORM**********************");
					System.out.println("1.POST TWEET");
					System.out.println("2.VIEW MY TWEETS");
					System.out.println("3.VIEW ALL TWEETS");
					System.out.println("4.VIEW ALL USERS");
					System.out.println("5.RESET PASSWORD");
					System.out.println("6.LOGOUT");
					System.out.println("=================================================================================");
					int option = sc.nextInt();
					
					switch(option) {
					case 1:
						PostTweet.postTweet(email_id);
						break;
					case 2:
						ViewMyTweets.viewMyTweets(email_id);
						break;
					case 3:
						ViewAllTweets.viewAllTweets();
						break;
					case 4:
						ViewAllUsers.viewAllUsers();
						break;
					case 5:
						UpdatePassword.resetPassword(email_id);
						break;
					case 6:
						Logout.updateStatusToLogout(email_id,"Inactive");
						check= false;
						break;
					}
				}
			}
			else {
				System.out.println("OOPS!! INCORRECT CREDENTIALS.LOGIN FAILED.");
				System.out.println("TRY AGAIN WITH REGISTERED USERNAME AND PASSWORD.");
			}
				
		}
		catch(SQLException e) {
			System.out.println("SQLException caught in register");
		}
		
	}
}
