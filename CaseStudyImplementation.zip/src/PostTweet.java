import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class PostTweet {
	static final String POST_TWEET_QUERY = "INSERT INTO TWEETS(EMAIL_ID,TWEETS) VALUES(?,?)";
	public static void postTweet(String email_id) {
		Scanner sc = new Scanner(System.in);
		try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
				PreparedStatement ps = con.prepareStatement(POST_TWEET_QUERY);){
			System.out.println("PLEASE ENTER YOUR TWEET!!!");
			String tweet = sc.nextLine();
		
			ps.setString(1, email_id);
			ps.setString(2, tweet);
			ps.executeUpdate();
		
	}
		catch(SQLException e) {
			System.out.println("SQLException caught in register");
		}
	}
}
