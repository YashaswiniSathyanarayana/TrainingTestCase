import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdatePassword {
	static final String FORGOT_PASSWORD_QUERY = "UPDATE USER_REGISTRATION SET PASSWORD = ? WHERE EMAIL_ID = ?;";
	
public static void resetPassword() {
	// TODO Auto-generated method stub
	try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
			PreparedStatement ps = con.prepareStatement(FORGOT_PASSWORD_QUERY);){
		Scanner sc = new Scanner(System.in);
		System.out.println("PLEASE ENTER THE REGISTERED EMAIL_ID");
		String email_id = sc.next();
		System.out.println("PLEASE ENTER THE NEW PASSWORD");
		String password = sc.next();
		ps.setString(1, password);
		ps.setString(2, email_id);
		ps.executeUpdate();
}
	catch(SQLException e) {
		System.out.println("Exception in resetPassword");
	}
}
static final String RESET_PASSWORD_QUERY = "UPDATE USER_REGISTRATION SET PASSWORD = ? WHERE EMAIL_ID = ?;";
public static void resetPassword(String email_id) {
	// TODO Auto-generated method stub
	try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
			PreparedStatement ps = con.prepareStatement(RESET_PASSWORD_QUERY);){
		Scanner sc = new Scanner(System.in);
		System.out.println("PLEASE ENTER THE NEW PASSWORD");
		String password = sc.next();
		ps.setString(1, password);
		ps.setString(2, email_id);
		ps.executeUpdate();
}
	catch(SQLException e) {
		System.out.println("Exception in resetPassword");
	}
	
}

}
