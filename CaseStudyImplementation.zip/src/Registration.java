import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.*;
import java.util.Scanner;

public class Registration {
	static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
	static final String REGISTRATION_QUERY = "INSERT INTO USER_REGISTRATION(NAME,EMAIL_ID,PASSWORD) VALUES(?,?,?);";
	
	public static void register() {
		try(Connection con = DriverManager.getConnection(D_URL,USER,PASS);
			PreparedStatement ps = con.prepareStatement(REGISTRATION_QUERY);){
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Registration");
		System.out.println("*************************************************");
		System.out.println("Enter the NAME");
		String name = sc.nextLine();
		System.out.println("Enter the EMAIL_ID");
		String email_id = sc.nextLine();
		System.out.println("Enter the PASSWORD");
		String password = sc.nextLine();
		ps.setString(1,name);
		ps.setString(2,email_id);
		ps.setString(3, password);
		
		ps.executeUpdate();
			
	}
		catch(SQLException e) {
			System.out.println(e);
		}

}
}
