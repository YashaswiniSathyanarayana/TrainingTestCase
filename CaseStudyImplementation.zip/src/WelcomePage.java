import java.util.Scanner;
import java.sql.DriverManager;

public class WelcomePage {
	static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
    
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("WELCOME TO TWITTER APP!!!!!");
		System.out.println("*************************************************");
		System.out.println("Please select from the below options");
		System.out.println("1.Register");
		System.out.println("2.Login");
		System.out.println("3.Forgot Password");
		
		Scanner sc = new Scanner(System.in);
		int option = sc.nextInt();
		
		if(option == 1) {
			Registration.register();
			}
		else if(option ==2) {
			Login.login();
		}
		else if(option ==3) {
			UpdatePassword.resetPassword();
		}
		else
			System.out.println("Please provide appropriate option from the menu");
		

	}

}
