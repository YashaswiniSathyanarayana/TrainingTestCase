import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ViewAllTweets {
	static final String VIEW_ALL_TWEETS = "SELECT * FROM TWEETS;";
	public static void viewAllTweets() {
		//Scanner sc = new Scanner(System.in);
		try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
				PreparedStatement ps = con.prepareStatement(VIEW_ALL_TWEETS);){
			System.out.println("VIEWING ALL TWEETS!!!");
			System.out.println("***************************************************");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getString("TWEETS"));
			}
	}
		catch(SQLException e) {
			System.out.println("SQLException caught in register");
		}
	}
}