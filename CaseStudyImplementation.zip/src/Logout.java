import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Logout {
	static final String LOGOUT_QUERY = "UPDATE USER_REGISTRATION SET ACTIVE = ? WHERE EMAIL_ID = ?;";
	public static void updateStatusToLogout(String email_id, String status) {
		// TODO Auto-generated method stub
		try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
				PreparedStatement ps = con.prepareStatement(LOGOUT_QUERY);){
			ps.setString(1, status);
			ps.setString(2, email_id);
			ps.executeUpdate();

	}
		catch(SQLException e) {
			System.out.println("Exception in resetPassword");
		}
	}
}
