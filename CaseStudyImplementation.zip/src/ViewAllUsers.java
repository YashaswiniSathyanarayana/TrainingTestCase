import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewAllUsers {
	static final String VIEW_ALL_USERS = "SELECT * FROM USER_REGISTRATION u JOIN TWEETS t ON u.EMAIL_ID=t.EMAIL_ID;";
	public static void viewAllUsers() {
		// TODO Auto-generated method stub
		try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
				PreparedStatement ps = con.prepareStatement(VIEW_ALL_USERS);){
			System.out.println("VIEWING ALL USERS!!!");
			System.out.println("***************************************************");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				System.out.print(rs.getString("NAME")+"----------------------");
				System.out.println(rs.getString("TWEETS"));
				
			}
		
	}
		catch(SQLException e) {
			System.out.println(e);
		}
	}
}
