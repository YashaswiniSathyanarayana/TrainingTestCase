import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ViewMyTweets {
	

	static final String VIEW_MYTWEETS = "SELECT * FROM TWEETS WHERE EMAIL_ID =? ;";

	public static void viewMyTweets(String email_id) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		try(Connection con = DriverManager.getConnection(WelcomePage.D_URL, WelcomePage.USER, WelcomePage.PASS);
				PreparedStatement ps = con.prepareStatement(VIEW_MYTWEETS);){
			System.out.println("YOUR TWEETS ARE AS FOLLOWS");
			System.out.println("***************************************************");
			ps.setString(1, email_id);
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getString("TWEETS"));
			}
		
	}
		catch(SQLException e) {
			System.out.println("SQLException caught in register");
		}
	}
}
