import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.Scanner;


public class Login {
	static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
    static final String QUERY = "select * from registration where email_id =? and password =?;";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			try(Connection con = DriverManager.getConnection(D_URL, USER, PASS);
				PreparedStatement ps = con.prepareStatement(QUERY);){
				
				Scanner sc = new Scanner(System.in);
				
				 System.out.println("Enter Email_id :");
				 String email = sc.nextLine();
				 System.out.println("Enter Password :");
				 String password = sc.nextLine();
				 
				 
				 ps.setString(1, email);
				 ps.setString(2, password);
				
				 ResultSet rs = ps.executeQuery();
				 
				 if(rs.next()) {
					 System.out.println("Login successful");
				 }
				 
//				 if((rs.getString("email_id").equals(email)) && (rs.getString("password").equals(password))) {
//					 System.out.println("Login successful");
//				 }
				 else{
					 System.out.println("Invalid credentials");
				 }
				 
				
			}
			catch(SQLException e) {
				
			}
	}

}
