import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.Scanner;


public class Registration {
	static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
    static final String QUERY = "insert into registration (fname,email_id,password) values(?,?,?);";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			try(Connection con = DriverManager.getConnection(D_URL, USER, PASS);
				PreparedStatement ps = con.prepareStatement(QUERY);){
				
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter Name :");
				 String name = sc.nextLine();
				 System.out.println("Enter Email_id :");
				 String email = sc.nextLine();
				 System.out.println("Enter Password :");
				 String password = sc.nextLine();
				 
				 ps.setString(1, name);
				 ps.setString(2, email);
				 ps.setString(3, password);
				 
				 ps.executeUpdate();
				
			}
			catch(SQLException e) {
				
			}
	}

}
