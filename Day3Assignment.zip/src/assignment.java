import java.util.Arrays;
import java.util.List;

class Vehicles{
	
	private String make = "KIA";
	
	public void move() {
		System.out.println("Vehicle is Moving");
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}
	
}

class Cars extends Vehicles{
	
	public void move() {
		System.out.println("Car is moving");
	}
}
public class assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicles v = new Vehicles();
		v.move();
		System.out.println("Make is : "+ v.getMake());
		
		Vehicles v1 = new Cars();
		v1.move();
		
		List<Integer> nums = Arrays.asList(2,4,3,9,8,7,6,10);
		nums.stream().map(n->n*10).sorted().forEach(System.out::println);

	}

}
